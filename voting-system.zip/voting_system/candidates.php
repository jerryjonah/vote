<!DOCTYPE HTML>
<!--
	Justice by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SUCC &mdash; Constitutional Council</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by gettemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="gettemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400, 900" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	<style>
	.button {
	    background-color: #4CAF50; /* Green */
	    border: none;
	    color: white;
	    padding: 4px 16px;
			border-radius: 60px;
	    text-align: center;
	    text-decoration: none;
	    display: inline-block;
	    font-size: 16px;
	    margin: 4px 2px;
	    -webkit-transition-duration: 0.4s; /* Safari */
	    transition-duration: 0.4s;
	    cursor: pointer;
	}

	.button1 {
	    background-color: #7ED321;
	    color: white;
	    border: 2px solid white;
	}

	.button1:hover {
	    background-color: white;
	    color: #7ED321;
	}
</style>

	</head>
	<body>
    <nav class="gtco-nav" role="navigation" style="background-color: #7ED321;">
  		<div class="container">
  			<div class="row">
  				<div class="col-sm-2 col-xs-12">
  					<div id="gtco-logo"><a href="index.php">SU<em>CC</em></a></div>
  				</div>
  				<div class="col-xs-10 text-right menu-1 main-nav">
  					<ul>
              <button class="button button1" onclick="window.location.href='/voting_system/voting_page.php?organization=SUG&submit=Submit'">Back</button>
  						<!-- For external page link -->
  						<!-- <li><a href="http://gettemplates.co/" class="external">External</a></li> -->
  					</ul>
  				</div>
  			</div>

  		</div>
  	</nav>

		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for Presidents</h1>
						<p class="sub">Gallery of the candidates for the post of presidents.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for Presidents</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/steward.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Steward Seshupo Magau</h2>
						<p>For President</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/carl.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Chwabo Carl Collins</h2>
						<p>For President</p>
						<p>Student <br>Software Engineering <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/gerald.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Nsong Fitz Gerald</h2>
						<p>For President</p>
						<p><p>For President</p>Student <br>Information and Communication Technology <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/maurice.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Ashu Maurice</h2>
						<p>For President</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/male_avatar.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Siwouaba jordan</h2>
						<p>For President</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/fon.JPG" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Ngum Buka Fon Nyuydze</h2>
						<p>Member</p>
						<p>Student <br>Software Engineering <br>ICT University, Messassi.</p>
					</div>
				</div>

			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for Secretary</h1>
						<p class="sub">Gallery of the candidates for the post of presidents.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for Secretary</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/male_avatar.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Djamen Leopold Yvon Rene</h2>
						<p>For Secretary</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/unity.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Diangha Unity Nidum</h2>
						<p>For Secretary</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for Treasurer</h1>
						<p class="sub">Gallery of the candidates for the post of treasurer.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for Treasurer</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/rose.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Moyou Rose</h2>
						<p>For Treasurer</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/vicky.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Vicky Lowe</h2>
						<p>For Treasurer</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/male_avatar.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Anaelle Vladimir</h2>
						<p>For Treasurer</p>
						<p>Student <br>Renewable Energy Engineering <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for Provost</h1>
						<p class="sub">Gallery of the candidates for the post of provost.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for Provost</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/siping.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Josue Siping</h2>
						<p>For Provost</p>
						<p>Student <br>Information and Communication Technology <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/pamela.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Olinga Pamela Pearl</h2>
						<p>For Provost</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for Welfare Officer</h1>
						<p class="sub">Gallery of the candidates for the post of welfare officer.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for Welfare Officer</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/pim.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Piim Michael</h2>
						<p>For Welfare Officer</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/isaac.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Abam isaac</h2>
						<p>For Welfare Officer</p>
						<p>Student <br>Business Management and Sustainable Development <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for ICT Faculty Head</h1>
						<p class="sub">Gallery of the candidates for the post of ICT faculty head.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for ICT Faculty Head</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/male_avatar.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Ebong Green Fielding Mesumbe </h2>
						<p>For ICT Faculty Head</p>
						<p>Student <br>Information Systems and Networking <br>ICT University, Messassi.</p>
					</div>
				</div>

				<div class="row team-item gtco-team">
					<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
						<div class="img-shadow">
							<img src="images/male_avatar.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
						<h2>Kushinga</h2>
						<p>For ICT Faculty Head</p>
						<p>Student <br>Information and Communication Technology <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
						<h1>Candidates for BMS Faculty Head</h1>
						<p class="sub">Gallery of the candidates for the post of BMS faculty head.</p>
						<p class="subtle-text animate-box" data-animate-effect="fadeIn">Candidates for BMS Faculty Head</p>
					</div>
				</div>
				<div class="row team-item gtco-team-reverse">
					<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
						<div class="img-shadow">
							<img src="images/ndam.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
						</div>
					</div>
					<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
						<h2>Ndam Njoya Inusa Junior </h2>
						<p>For BMS Faculty Head</p>
						<p>Student <br>Information Systems and Networking <br>ICT University, Messassi.</p>
					</div>
				</div>
			</div>
		</section>

	<footer id="gtco-footer" role="contentinfo">
		<div class="container">

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2018 Student Union Constitutional Council. All Rights Reserved.</small>
						<small class="block">Designed by <a href="https://www.linkedin.com/in/jerry-j-56642185/" target="_blank">Jerry Jonah</a> and <a href="https://www.linkedin.com/in/mbachan-fabrice-11593b165/" target="_blank">Mbachan Fabrice</a></small>
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
