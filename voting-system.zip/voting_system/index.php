
<!DOCTYPE HTML>
<!--
	Jerry Jonah
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SUCC &mdash; Constitutional Council</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by gettemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="gettemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />



	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	<style>
	.button {
	    background-color: #4CAF50; /* Green */
	    border: none;
	    color: white;
	    padding: 14px 35px;
			border-radius: 60px;
	    text-align: center;
	    text-decoration: none;
	    display: inline-block;
	    font-size: 16px;
	    margin: 4px 2px;
	    -webkit-transition-duration: 0.4s; /* Safari */
	    transition-duration: 0.4s;
	    cursor: pointer;
	}

	.button1 {
	    background-color: white;
	    color: #7ED321;
	    border: 2px solid #7ED321;
	}

	.button1:hover {
	    background-color: #7ED321;
	    color: white;
	}
</style>

	</head>
	<body>

	<div class="gtco-loader"></div>

	<div id="page">
	<nav class="gtco-nav" role="navigation">
		<div class="container">
			<div class="row">
				<div class="col-sm-2 col-xs-12">
					<div id="gtco-logo"><a href="index.html">SU<em>CC</em></a></div>
				</div>
				<div class="col-xs-10 text-right menu-1 main-nav">
					<ul>
						<li class="active"><a href="#" data-nav-section="home">Home</a></li>
						<li><a href="#" data-nav-section="about">About</a></li>
						<li><a href="#" data-nav-section="our-team">Our Team</a></li>
						<li><a href="login.php" data-nav-section="login">Login</a></li>
						<li class="btn-cta"><a href="#" data-nav-section="contact"><span>Contact</span></a></li>
						<!-- For external page link -->

					</ul>
				</div>
			</div>

		</div>
	</nav>

	<section id="gtco-hero" class="gtco-cover" style="background-image: url(images/img_bg_4.JPG);"  data-section="home"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="display-t">
						<div class="display-tc">
							<h2 class="animate-box" data-animate-effect="fadeIn">The ICT University Cameroon</h2>
							<h1 class="animate-box" data-animate-effect="fadeIn">Student Union Constitutional Council</h1>
							<p class="gtco-video-link animate-box" data-animate-effect="fadeIn"><a href="https://www.youtube.com/watch?v=fp0AMGMD5pM" class="popup-vimeo"><i class="icon-controller-play"></i></a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="gtco-about" data-section="about">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
					<h1>Welcome To The SUCC</h1>
					<p class="sub">To ensure the continuity of good governance of the Student Union Government (SUG); improve transparency through consistent communication with students and mediate the gap between the students and administration.</p>
					<p class="subtle-text animate-box" data-animate-effect="fadeIn">Welcome</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-md-pull-1 animate-box" data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/ictu.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2 class="heading-colored">Excellence &amp; Honesty</h2>
					<p>The Student Union Constitutional Council is made up of a group of students from across different departments who oversees what the Student Union Government does and in charge of making important decisions about the way things are to be run for the student’s interest. The Student Union Council elects an Executive Board for the implementation of the plan of action and, at the same time, oversees its activities. If the activities of the Executive Board are not satisfactory, the Student Union Council can dismiss the Executive Board with a vote of no confidence. </p>
					<p><a href="#" class="read-more">Read more <i class="icon-chevron-right"></i></a></p>
				</div>
			</div>
		</div>
	</section>

	<section id="gtco-our-team" data-section="our-team">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
					<h1>Our Team</h1>
					<p class="sub">Our team is made up of young, devoted and dedicated students who have the vision and passion for to ensure that the SUG performs their duties and also to maintain a good link between the SUG and the Administration.</p>
					<p class="subtle-text animate-box" data-animate-effect="fadeIn">Our Team</p>
				</div>
			</div>
			<div class="row team-item gtco-team-reverse">
				<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
					<div class="img-shadow">
						<img src="images/img_team_1.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
					<h2>Mbachan Fabrice</h2>
					<p>President</p>
					<p>fabricetanwan.mbachan@ictuniversity.org <br>+237 662 050 455 <br>Student <br>Information Systems and Networking <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team">
				<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/peace.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2>Peace Akabike</h2>
					<p>Secretary</p>
					<p>npeace81@gmail.com <br>+237 662 050 455 <br>Student <br>Information Systems and Networking <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team-reverse">
				<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
					<div class="img-shadow">
						<img src="images/img_team_3.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
					<h2>Naseli Okha</h2>
					<p>Spokesman</p>
					<p>naseliokhaiyaz@gmail.com <br>+237 670 112 444 <br>Student <br>Software Engineering <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team">
				<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/img_team_4.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2>Tamunang Courage</h2>
					<p>Member</p>
					<p>tamunang.courage@ictuniversity.org <br>+237 672 153 402 <br>Student <br>Information and Communication Technology <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team-reverse">
				<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
					<div class="img-shadow">
						<img src="images/img_team_5.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
					<h2>Aristide Sunjo</h2>
					<p>Member</p>
					<p>aris.sunjo@gmail.com <br>+237 652 273 889 <br>Student <br>Software Engineering <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team">
				<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/atangana.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2>Atangana Anzie Anne</h2>
					<p>Member</p>
					<p>antanganaanne@gmail.com <br>+237 691 473 334 <br>Student <br>Accounting Information Technology <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team-reverse">
				<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
					<div class="img-shadow">
						<img src="images/inno.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
					<h2>Mefoe Innocent</h2>
					<p>Member</p>
					<p>mefoeenyougou.innocent@ictuniversity.org <br>+237 693 298 641 <br>Student <br>Renewable Energy Engineering <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team">
				<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/ericka.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2>Tatchum Ericka</h2>
					<p>Member</p>
					<p>tatchumericka@gmail.com <br>+237 698 400 636 <br>Student <br>Accounting Information Technology <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team-reverse">
				<div class="col-md-6 col-md-push-7 animate-box" data-animate-effect="fadeInRight">
					<div class="img-shadow">
						<img src="images/img_team_9.jpg" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6  col-md-pull-6 animate-box" data-animate-effect="fadeInRight">
					<h2>Jerry Jonah</h2>
					<p>Secretary</p>
					<p>npeace81@gmail.com <br>+237 662 050 455 <br>Student <br>Information Systems and Networking <br>ICT University, Messassi.</p>
				</div>
			</div>

			<div class="row team-item gtco-team">
				<div class="col-md-6 col-md-pull-1 animate-box"  data-animate-effect="fadeInLeft">
					<div class="img-shadow">
						<img src="images/chelsea.png" class="img-responsive" alt="&copy; 2018 Student Union Constitutional Council. All Rights Reserved.">
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInLeft">
					<h2>Tarbot Chelsea</h2>
					<p>Member</p>
					<p>tarbotchelsea@gmail.com <br>+237 651 629 374 <br>Student <br>Accounting Information Technology <br>ICT University, Messassi.</p>
				</div>
			</div>

		</div>
	</section>

	<section id="gtco-contact" data-section="contact">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
					<h1>Contact Us</h1>
					<p class="sub">Hello, You can just write to us either via the phone number or via the email address and we will reply to you immediately.</p>
					<p class="subtle-text animate-box" data-animate-effect="fadeIn">Contact</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 col-md-push-6 animate-box">
					<form action="#">
						<div class="form-group">
							<label for="username" class="sr-only">Username</label>
							<input type="text" class="form-control" placeholder="username" id="username">
						</div>
						<div class="form-group">
							<label for="email" class="sr-only">Email</label>
							<input type="text" class="form-control" placeholder="Email" id="email">
						</div>
						<div class="form-group">
							<label for="message" class="sr-only">Message</label>
							<textarea name="message" id="message" class="form-control" cols="30" rows="7" placeholder="Message"></textarea>
						</div>
						<div class="form-group">
							<input type="submit" value="Send Message" class="btn btn-primary">
						</div>
					</form>
				</div>
				<div class="col-md-4 col-md-pull-6 animate-box">
					<div class="gtco-contact-info">
						<ul>
							<li class="address">ICT University, Dispensaire Messassi</li>
							<li class="phone"><a href="tel:+237670714343">+237 670 714 343 (WhatsApp)</a></li>
							<li class="email"><a href="mailto:jonah.jerry@ictuniversity.org">jonah.jerry@ictuniversity.org</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="gtco-contact" data-section="login">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-8 col-md-offset-2 heading animate-box" data-animate-effect="fadeIn">
					<h1>Login to vote</h1>
					<p class="sub">Hello to my fellow voters, Click on the button below to get access to the login panel. Then you will provide your valid matricule number. In the case you are unable to login with your matricule, kindly write to the contact you see below! <br>Vote for the right person</p>
					<p class="subtle-text animate-box" data-animate-effect="fadeIn">Login</p>
					<button class="button button1" onclick="window.location.href='/voting_system/login.php'">Login</button>
				</div>
			</div>
		</div>
	</section>

	<footer id="gtco-footer" role="contentinfo">
		<div class="container">

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2018 Student Union Constitutional Council. All Rights Reserved.</small>
						<small class="block">Designed by <a href="https://www.linkedin.com/in/jerry-j-56642185/" target="_blank">Jerry Jonah</a> and <a href="https://www.linkedin.com/in/mbachan-fabrice-11593b165/" target="_blank">Mbachan Fabrice</a></small>
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
