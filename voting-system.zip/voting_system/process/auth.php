<?php
//Create authentication

//Start session
session_start();
if(!isset($_SESSION['STUD_ID']) || !isset($_SESSION['STUD_ID'])) {
    header("location: http://localhost/voting_system/index.php");
    exit();
}


?>