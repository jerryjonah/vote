<?php
session_start();

// initializing variables
$Username = "";
$Email    = "";
$Message    = "";

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'voting');

// REGISTER USER
if (isset($_POST['reg_user'])) {
  // receive all input values from the form
  $Username = mysqli_real_escape_string($db, $_POST['Username']);
  $Email = mysqli_real_escape_string($db, $_POST['Email']);
  $Message = mysqli_real_escape_string($db, $_POST['Message']);


  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($Username)) { array_push($errors, "Username is required"); }
  if (empty($Email)) { array_push($errors, "Email is required"); }
  if (empty($Message)) { array_push($errors, "Message is required"); }

  }

  // first check the database to make sure
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM contact WHERE Username='$Username' OR Email='$Email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  //$user = mysqli_fetch_assoc($result);


  // Finally, register user if there are no errors in the form

  	$query = "INSERT INTO contact(Username, Email, Message)
  			  VALUES('$Username', '$Email', '$Message')";
  	mysqli_query($db, $query);
  	$_SESSION['username'] = $Username;
  	$_SESSION['success'] = "Thanks your message has been delivered";




// ...
