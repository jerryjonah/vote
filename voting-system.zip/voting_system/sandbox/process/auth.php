<?php
//Create authentication

//Start session
session_start();

if(!isset($_SESSION['ADMIN_ID']) || !isset($_SESSION['ADMIN_ID'])) {
    header("location: http://localhost/voting_system/sandbox/index.php");
    exit();
}