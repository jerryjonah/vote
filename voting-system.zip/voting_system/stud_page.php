<?php
//Include authentication
require("process/auth.php");

//Include database connection
require("config/db.php");

//Include class Voting
require("classes/Voting.php");
?>

<!DOCTYPE HTML>
<!--
	Justice by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SUCC &mdash; Constitutional Council</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by gettemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="gettemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400, 900" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	<style>

h3 {
	color: white;
}

.button {
		background-color: #7ED321;
		color: white;
		border: 2px;
		border-radius: 40px;
		padding: 6px 20px;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
}

.button:hover {
		background-color: #ffffff;
		color: #7ED321;
		border: 2px;
		border-radius: 40px;
		padding: 4px 20px;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
}
</style>

	</head>
	<body  style="background-color: #7ED321; text-align: center;">

		<div class="gtco-loader"></div>

		<div id="page">
		<nav class="gtco-nav" role="navigation">
			<div class="container">
				<div class="row">
					<div class="col-sm-2 col-xs-12">
						<div id="gtco-logo"><a href="index.php">SU<em>CC</em></a></div>
					</div>
					<div class="col-xs-10 text-right menu-1 main-nav">
						<ul>
                <button class="button button1" onclick="window.location.href='/voting_system/process/logout.php'">Logout</button>
              </ul>
							<!--<li class="btn-cta"><a href="#" data-nav-section="contact"><span>login</span></a></li>-->
							<!-- For external page link -->
							<!-- <li><a href="http://gettemplates.co/" class="external">External</a></li> -->
						</ul>
					</div>
				</div>

			</div>
		</nav>
    <?php
    $readOrganization = new Voting();
    $rtnReadOrg = $readOrganization->READ_ORG();
    ?>
		<section id="gtco-our-team" data-section="our-team">
			<div class="container">
			    <div class="row">
			        <div class="col-md-4 col-md-offset-4">
                <h3 style="text-align: center;">Select Organization</h3><hr />
                <h4 style="color: white;">Welcome <?php echo $_SESSION['NAME']; ?></h4>
                <?php if($rtnReadOrg) { ?>
                <form action="voting_page.php" method="GET" role="form">
                    <div class="form-group">
                        <label for="organization" style="color: white;">Organization</label>
                        <select required class="form-control" name="organization">
                            <option value="">*****Select Organization*****</option>
                            <?php while($rowOrg = $rtnReadOrg->fetch_assoc()) { ?>
                            <option value="<?php echo $rowOrg['org']; ?>"><?php echo $rowOrg['org']; ?></option>
                            <?php } //End while ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="submit" value="Submit" class="botton button1">
                    </div>
                </form>
                    <?php $rtnReadOrg->free(); ?>
                <?php } //End if ?>
            </div>
			        </div>
			    </div>
			</div>
		</div>

			</section>


	<footer id="gtco-footer" role="contentinfo">
		<div class="container">

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; 2018 Student Union Constitutional Council. All Rights Reserved.</small>
						<small class="block">Designed by <a href="https://www.linkedin.com/in/jerry-j-56642185/" target="_blank">Jerry Jonah</a> and <a href="https://www.linkedin.com/in/mbachan-fabrice-11593b165/" target="_blank">Mbachan Fabrice</a></small>
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>
