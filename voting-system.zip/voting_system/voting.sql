-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 28, 2018 at 07:35 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `name`) VALUES
(1, 'admin', '@dminsucc10', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `	Email` varchar(100) NOT NULL,
  `Message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nominees`
--

CREATE TABLE `nominees` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL,
  `name` varchar(60) NOT NULL,
  `course` varchar(60) NOT NULL,
  `year` varchar(3) NOT NULL,
  `stud_id` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nominees`
--

INSERT INTO `nominees` (`id`, `org`, `pos`, `name`, `course`, `year`, `stud_id`) VALUES
(19, 'SUG', 'President', 'Chwabo Carl Collins Wayig', 'SEN', '3', 'ICTU1040494'),
(20, 'SUG', 'President', 'Ngum Buka Fon Nyuydze', 'SEN', '2', 'ICTU1040565'),
(21, 'SUG', 'President', 'Nsong Fitz Gerald', 'ICT', '2', 'ICTU1040623'),
(22, 'SUG', 'President', 'Siwouaba Jordan', 'BMS', '2', 'ICTU2050589'),
(23, 'SUG', 'President', 'Ashu Maurice', 'BMS', '2', 'ICTU2070528'),
(24, 'SUG', 'President', 'Steward Seshupo Magau', 'BMS', '3', 'ICTU2060672'),
(25, 'SUG', 'Secretary', 'Djamen Leopold Yvon Rene', 'ICT', '1', 'ICTU10'),
(26, 'SUG', 'Secretary', 'Diangha Unity Nidum', 'ACC', '2', 'ICTU2070675'),
(27, 'SUG', 'Treasurer', 'Moyou Rose', 'BMS', '2', 'ICTU2060590'),
(28, 'SUG', 'Treasurer', 'Vicky Lowe', 'BMS', '2', 'ICTU2070526'),
(29, 'SUG', 'Treasurer', 'Anaelle Vladimir', 'REN', '1', 'no'),
(30, 'SUG', 'Provost', 'Josue Siping', 'ICT', '2', 'ICTU1040855'),
(31, 'SUG', 'Provost', 'Olinga Pamela Pearl', 'BMS', '2', 'ICTU1020576'),
(32, 'SUG', 'Welfare Officer', 'Abam Isaac (ICE)', 'BMS', '2', 'ICTU5060592'),
(33, 'SUG', 'Welfare Officer', 'Piim Michael', 'BMS', '2', 'ICTU2080611'),
(34, 'SUG', 'BMS Faculty', 'Ndam Njoya Inusa Junior', 'BMS', '4', 'ICTU2070446'),
(35, 'SUG', 'ICT Faculty', 'Ebong Green Fielding Mesumbe', 'ISN', '4', 'ICTU1020615');

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`id`, `org`) VALUES
(5, 'SUG');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `org`, `pos`) VALUES
(15, 'SUG', 'President'),
(16, 'SUG', 'Secretary'),
(17, 'SUG', 'Treasurer'),
(18, 'SUG', 'Provost'),
(19, 'SUG', 'Welfare Officer'),
(20, 'SUG', 'BMS Faculty'),
(21, 'SUG', 'ICT Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `voters`
--

CREATE TABLE `voters` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `course` varchar(60) NOT NULL,
  `year` varchar(2) NOT NULL,
  `stud_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voters`
--

INSERT INTO `voters` (`id`, `name`, `course`, `year`, `stud_id`) VALUES
(12, 'Jerry Jonah', 'ISN', '4', 'ICTU1010408'),
(13, 'Mbachan Fabrice', 'ISN', '4', 'ICTU1010409'),
(14, 'Naseli Okha', 'ICT', '3', 'ICTU1010410'),
(15, 'Gomoko Natacha', 'ICT', '3', 'ICTU1010411'),
(16, 'Siate Stella', 'ICT', '3', 'ICTU1010412'),
(17, 'Kelsey Nforgwei', 'ICT', '3', 'ICTU1010413'),
(18, 'Chuo Brandon', 'ICT', '3', 'ICTU1010414'),
(19, 'Koffi Kenneth', 'ICT', '3', 'ICTU1010415');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `org` varchar(60) NOT NULL,
  `pos` varchar(60) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `voters_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `org`, `pos`, `candidate_id`, `voters_id`) VALUES
(36, 'SUG', 'President', 23, 12),
(37, 'SUG', 'Secretary', 26, 12),
(38, 'SUG', 'Treasurer', 28, 12),
(39, 'SUG', 'Provost', 31, 12),
(40, 'SUG', 'Welfare Officer', 33, 12),
(41, 'SUG', 'BMS Faculty', 34, 12),
(42, 'SUG', 'ICT Faculty', 35, 12),
(43, 'SUG', 'President', 20, 13),
(44, 'SUG', 'Secretary', 0, 13),
(45, 'SUG', 'Treasurer', 0, 13),
(46, 'SUG', 'Provost', 31, 13),
(47, 'SUG', 'Welfare Officer', 33, 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nominees`
--
ALTER TABLE `nominees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voters`
--
ALTER TABLE `voters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nominees`
--
ALTER TABLE `nominees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `voters`
--
ALTER TABLE `voters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
