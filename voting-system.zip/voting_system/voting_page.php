<?php
//Include authentication
include("process/auth.php");

//Include database connection
include("config/db.php");

//Include class Voting
include("classes/Voting.php");
?>
<!DOCTYPE HTML>
<!--
	Justice by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SUCC &mdash; Constitutional Council</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by gettemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="gettemplates.co" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400, 900" rel="stylesheet"> -->

	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Flexslider -->
	<link rel="stylesheet" href="css/flexslider.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	<style>
footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: red;
}
h3 {
	color: white;
}

.button {
		background-color: #7ED321;
		color: white;
		border: 2px;
		border-radius: 40px;
		padding: 6px 20px;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
}

.button:hover {
		background-color: #ffffff;
		color: #7ED321;
		border: 2px;
		border-radius: 40px;
		padding: 4px 20px;
		font-size: 16px;
		margin: 4px 2px;
		cursor: pointer;
}
.dropbtn {
  background-color: #7ED321;
  color: white;
  border: 2px;
  border-radius: 40px;
  padding: 6px 20px;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    text-align: center;
    background-color: #fff;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: #7ED321;
    padding: 12px 12px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #fff;
    color: #7ED321;
}
</style>

	</head>
	<body  style="background-color: #7ED321; text-align: center;">

		<div class="gtco-loader"></div>

		<div id="page">
		<nav class="gtco-nav" role="navigation">
			<div class="container">
				<div class="row">
					<div class="col-sm-2 col-xs-12">
						<div id="gtco-logo"><a href="index.php">SU<em>CC</em></a></div>
					</div>
					<div class="col-xs-10 text-right menu-1 main-nav">
						<ul>
                <button class="button button1" onclick="window.location.href='/voting_system/stud_page.php'">Back</button>
                <button class="button button1" onclick="window.location.href='/voting_system/candidates.php'">Candidates</button>
                <button class="button button1" onclick="window.location.href='/voting_system/process/logout.php'">Logout</button>
              </ul>
							<!--<li class="btn-cta"><a href="#" data-nav-section="contact"><span>login</span></a></li>-->
							<!-- For external page link -->
							<!-- <li><a href="http://gettemplates.co/" class="external">External</a></li> -->
						</ul>
					</div>
				</div>

			</div>
		</nav>
<?php
if(isset($_GET['organization'])) {
    $org = $_GET['organization'];
}
?>

<?php

$readPos = new Voting();
$rtnReadPos = $readPos->READ_POSITION($org);

?>

<section id="gtco-our-team" data-section="our-team">
  <?php
  if(isset($_GET['organization'])) {
      $org = $_GET['organization'];
  }
  ?>

  <?php

  $readPos = new Voting();
  $rtnReadPos = $readPos->READ_POSITION($org);

  ?>

  <div class="container">
      <div class="row">
          <?php if($rtnReadPos) { ?>
          <div class="col-md-6 col-md-offset-3">
              <?php
              if(isset($_POST['vote'])) {
                  $org            = trim($_POST['org']);
                  $pos            = trim($_POST['pos']);
                  $candidate_id   = trim($_POST['nominee']);
                  $voters_id       = trim($_POST['voter_id']);


                  $insertVote = new Voting();
                  $rtnInsertVote = $insertVote->VOTE_NOMINEE($org, $pos, $candidate_id, $voters_id);
              }

              ?>
              <div class="voting-con">

                  <h4 style="text-align: center; color: #fff;"><?php echo $org; ?> Voting Page</h4><hr />
                  <?php while($rowPos = $rtnReadPos->fetch_assoc()) { ?>
                  <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" role="form">
                      <p class="help-block" style="color: #fff;"><b><?php echo $rowPos['pos']; ?></b></p>
                          <?php
                          $readNominee = new Voting();
                          $rtnReadNominee = $readNominee->READ_NOMINEES($org, $rowPos['pos']);
                          ?>

                          <?php if($rtnReadNominee) { ?>
                              <div class="form-group">
                                  <select name="nominee" class="form-control">
                                      <option value="">*****Pick Candidate*****</option>
                                      <?php while($rowNominee = $rtnReadNominee->fetch_assoc()) { ?>
                                      <option value="<?php echo $rowNominee['id']; ?>"><?php echo $rowNominee['name']; ?></option>
                                      <?php } //End while ?>
                                  </select>
                              </div>
                          <?php } //End if ?>
                          <input type="hidden" name="org" value="<?php echo $org; ?>">
                          <input type="hidden" name="pos" value="<?php echo $rowPos['pos']; ?>">
                          <input type="hidden" name="voter_id" value="<?php echo $_SESSION['ID']; ?>">

                      <?php
                      $validateVote = new Voting();
                      $rtnValVote = $validateVote->VALIDATE_VOTE($org, $rowPos['pos'], $_SESSION['ID'])
                      ?>
                          <button type="submit" name="vote"
                                  <?php if($rtnValVote->num_rows > 0) { ?>
                                  <?php echo "class='btn btn-default disabled'>"; ?>
                                  <?php } else { ?>
                                  <?php echo "class='btn btn-info'>"; ?>
                                  <?php } //End if ?>
                              Vote
                          </button>
                  </form><hr />
                  <?php } //End while ?>
              </div>
          </div>
          <?php } //End if ?>
      </div>
  </div>

  </section>


<footer id="gtco-footer" role="contentinfo">
<div class="container">

  <div class="row copyright">
    <div class="col-md-12">
      <p class="pull-left">
        <small class="block">&copy; 2018 Student Union Constitutional Council. All Rights Reserved.</small>
        <small class="block">Designed by <a href="https://www.linkedin.com/in/jerry-j-56642185/" target="_blank">Jerry Jonah</a> and <a href="https://www.linkedin.com/in/mbachan-fabrice-11593b165/" target="_blank">Mbachan Fabrice</a></small>
      </p>
      <p class="pull-right">
        <ul class="gtco-social-icons pull-right">
          <li><a href="#"><i class="icon-twitter"></i></a></li>
          <li><a href="#"><i class="icon-facebook"></i></a></li>
          <li><a href="#"><i class="icon-linkedin"></i></a></li>
          <li><a href="#"><i class="icon-dribbble"></i></a></li>
        </ul>
      </p>
    </div>
  </div>

</div>
</footer>
</div>

<div class="gototop js-top">
<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
</div>

<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="js/jquery.waypoints.min.js"></script>
<!-- Stellar -->
<script src="js/jquery.stellar.min.js"></script>
<!-- Magnific Popup -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/magnific-popup-options.js"></script>
<!-- Main -->
<script src="js/main.js"></script>

</body>
</html>
